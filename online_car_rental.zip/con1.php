<?php
	$connection=mysqli_connect("localhost","root","password","book");
	/*if($connection)
	{
	echo " Successfull";
	}
	else{
	echo "Error:".mysqli_error($connection);
	}*/
?>
